import tkinter as tk
from Randomizer.ui_grprndmzr import RandomizerGUI

if __name__ == "__main__":
    root = tk.Tk()
    app = RandomizerGUI(root)  
    root.mainloop()  